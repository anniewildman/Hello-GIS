# Author: Claudia Wolff
# Date: 2017-10-05
# Purpose:Mediterranean coastal database
# Processing the vertical land movement data 

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1.	Download netCDF: http://www.psmsl.org/train_and_info/geo_signals/gia/peltier/ drad250.1grid.ICE5Gv1.3_VM2_L90_2012.nc
#		#Postprocessing:
#		Create NetCDFRaster Layer - Peltier2004
#		Raster to ASCII peltier2004.txt
#		Edit ASCII file xll corner to 0
#		ASCII to raster
#		Export data --> Extent -180 (left) 180 (right) 
#		Clip data to study area extent. Name it pelt2012_med.tif 
# 2. Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3. Create a midpoint shapefile of the segments. Name it segment_midpt.shp


##import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\uplift"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\uplift"

#Resample to the same cellsize as the zones
arcpy.Resample_management(in_raster=str(dir_input) + "\\pelt2012_med", out_raster=str(dir_output) + "\\Pelt12_medre", 
	cell_size="0,00083333333", resampling_type="NEAREST")
	
#Extract by mask in order to get all cells that are lying directly on the coast
arcpy.gp.ExtractByMask_sa(str(dir_output) + "\\Pelt12_medre", str (dir_path) + "\\input\\Coastal_Segments\\Mediterranean_segments.shp", 
   str(dir_output) + "\\Pelt12_extr")
print 'extract done'

#Raster extract to points
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\Pelt12_extr", out_point_features=str(dir_output) + "\\Pelt12_extr_points.shp", raster_field="Value")


target_features= str(dir_input) + "\\segment_midpt.shp"
join_features=str(dir_output) + "\\Pelt12_extr_points.shp"
out_feature_class=str(dir_output) + "\\Peltier2004.shp"

arcpy.SpatialJoin_analysis(target_features, join_features, out_feature_class, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", match_option="CLOSEST")


#converting dbase to csv
csv_fn = str(dir_output) + "\\Peltier2004.csv"
table = dbf.Table(str(dir_output) + "\\Peltier2004.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

result = pd.read_csv (str(dir_output) + "\\Peltier2004.csv")
result = result [['id_p','grid_code']]
result.columns = ['locationid', 'VerticalMovement']

result.to_csv (str(dir_output) + "\\uplift_final.csv", sep =';', mode='w', index=False)

