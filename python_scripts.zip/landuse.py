# Author: Claudia Wolff
# Date: 2017-10-11
# Purpose:Mediterranean coatal database
# Processing the landuse data 

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. Download the GLOBCOVER_L4_200901_200912_V2.3.tif from http://due.esrin.esa.int/page_globcover.php. 300m resolultion. Clip to study extent. Name it glo_grid
# 2. Create a real area grid (name it real_area.tif) based on this equation https://badc.nerc.ac.uk/help/coordinates/cell-surf-area.html 
# 3. Download the Coastal_assessment_units (Coastal_assessment_units.tif) from the figshare folder.

#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\landuse"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\landuse"

 ##Reclassifiy data

#1 = Forest
#2 = Urban
#3 = Arable landuse
#4 = Open space


#Value	Label                                                                                                                                                                  New Value
#11	Post-flooding or irrigated croplands (or aquatic)                                                                                                                          	3
#14	Rainfed croplands                                                                                                                                                          	3
#20	Mosaic cropland (50-70%) / vegetation (grassland/shrubland/forest) (20-50%)                                                                                                	3  
#30	Mosaic vegetation (grassland/shrubland/forest) (50-70%) / cropland (20-50%)                                                                                                	1
#40	Closed to open (>15%) broadleaved evergreen or semi-deciduous forest (>5m)                                                                                           	   	1
#50	Closed (>40%) broadleaved deciduous forest (>5m)                                                                                                                           	1
#60	Open (15-40%) broadleaved deciduous forest/woodland (>5m)                                                                                                                  	1
#70	Closed (>40%) needleleaved evergreen forest (>5m)                                                                                                                          	1
#90	Open (15-40%) needleleaved deciduous or evergreen forest (>5m)                                                                                                             	1
#100	Closed to open (>15%) mixed broadleaved and needleleaved forest (>5m)                                                                                               	1
#110	Mosaic forest or shrubland (50-70%) / grassland (20-50%)                                                                                                                1
#120	Mosaic grassland (50-70%) / forest or shrubland (20-50%)                                                                                                                1
#130	Closed to open (>15%) (broadleaved or needleleaved, evergreen or deciduous) shrubland (<5m)                                                               				3
#140	Closed to open (>15%) herbaceous vegetation (grassland, savannas or lichens/mosses)                                                                             		4
#150	Sparse (<15%) vegetation                                                                                                                                                4
#160	Closed to open (>15%) broadleaved forest regularly flooded (semi-permanently or temporarily) - Fresh or brackish water                             						NoData (wetlands)
#170	Closed (>40%) broadleaved forest or shrubland permanently flooded - Saline or brackish water                                                                   			NoData (wetlands)
#180	Closed to open (>15%) grassland or woody vegetation on regularly flooded or waterlogged soil - Fresh, brackish or saline water                     						4
#190	Artificial surfaces and associated areas (Urban areas >50%)                                                                                                             2
#200	Bare areas                                                                                                                                                              4
#210	Water bodies                                                                                                                                                            4
#220	Permanent snow and ice                                                                                                                                                  4
#230	No data (burnt areas, clouds,…)                                                                                                                                         NoData


# #Forest
# arcpy.gp.Reclassify_sa(str (dir_input) + "\\glo_grid", "VALUE", "11 20 0;30 120 1;130 220 0;230 NODATA", str (dir_output) + "\\Forest.tif", "DATA")

# #Urban
# arcpy.gp.Reclassify_sa(str (dir_input) + "\\glo_grid", "VALUE", "11 180 0;190 1;200 220 0;230 NODATA", str (dir_output) + "\\urban.tif", "DATA")

# #Arable land
# arcpy.gp.Reclassify_sa(str (dir_input) + "\\glo_grid", "VALUE", "11 20 1;30 120 0;130 1;140 220 0;230 NODATA", str (dir_output) + "\\arable_land.tif", "DATA")

# #Open space
# arcpy.gp.Reclassify_sa(str (dir_input) + "\\glo_grid", "VALUE", "11 130 0;140 150 1;160 170 0;180 1;190 0;200 220 1;230 NODATA", str (dir_output) + "\\open_space.tif", "DATA")

# print "Reclassify Globcover done"
# print (datetime.datetime.now().time()) 

# #Resample to the srtm cellsize
# arcpy.Resample_management(in_raster=str (dir_output) + "\\Forest.tif", out_raster=str (dir_output) + "\\Forest_rs.tif", cell_size="0,00083333333", resampling_type="NEAREST")
# arcpy.Resample_management(in_raster=str (dir_output) + "\\urban.tif", out_raster=str (dir_output) + "\\urban_rs.tif", cell_size="0,00083333333", resampling_type="NEAREST")
# arcpy.Resample_management(in_raster=str (dir_output) + "\\arable_land.tif", out_raster=str (dir_output) + "\\arable_land_rs.tif", cell_size="0,00083333333", resampling_type="NEAREST")
# arcpy.Resample_management(in_raster=str (dir_output) +"\\open_space.tif", out_raster=str (dir_output) +"\\open_space_rs.tif", cell_size="0,00083333333", resampling_type="NEAREST")

# print "Resample Globcover done"
# print (datetime.datetime.now().time())  

# ##Zonal statistics 
# arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\Forest_rs.tif", str (dir_output) + "\\forest.dbf", "DATA", "ALL")
# arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\urban_rs.tif", str (dir_output) + "\\urban.dbf", "DATA", "ALL")
# arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\arable_land_rs.tif", str (dir_output) + "\\arable_land.dbf", "DATA", "ALL")
# arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) +"\\open_space_rs.tif", str (dir_output) + "\\open_space.dbf", "DATA", "ALL")

# print "Zonal Statistics Globcover done"
# print (datetime.datetime.now().time()) 

#converting dbase to csv
csv_fn = str (dir_output) + "\\forest.csv"
table = dbf.Table(str (dir_output) + "\\forest.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) + "\\urban.csv"
table = dbf.Table(str (dir_output) + "\\urban.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) + "\\arable_land.csv"
table = dbf.Table(str (dir_output) + "\\arable_land.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) + "\\open_space.csv"
table = dbf.Table(str (dir_output) + "\\open_space.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

##Calculate the absolute numbers/ the area per landuse type
## landuse times real area grid
arcpy.gp.Times_sa(str (dir_output) + "\\Forest_rs.tif", str(dir_input) + "\\real_area.tif", str (dir_output) + "\\Forest_area.tif")
arcpy.gp.Times_sa(str (dir_output) + "\\urban_rs.tif", str(dir_input) + "\\real_area.tif", str (dir_output) + "\\urban_area.tif")
arcpy.gp.Times_sa(str (dir_output) + "\\arable_land_rs.tif", str(dir_input) + "\\real_area.tif", str (dir_output) + "\\arable_land_area.tif")
arcpy.gp.Times_sa(str (dir_output) +"\\open_space_rs.tif", str(dir_input) + "\\real_area.tif", str (dir_output) +"\\open_space_area.tif")

print "Times real area grid done"
print (datetime.datetime.now().time()) 

#zonal statistics
arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\Forest_area.tif", str (dir_output) +"\\forest_area.dbf", "DATA", "ALL")
arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\urban_area.tif", str (dir_output) +"\\urban_area.dbf", "DATA", "ALL")
arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) + "\\arable_land_area.tif", str (dir_output) +"\\arable_area.dbf", "DATA", "ALL")
arcpy.gp.ZonalStatisticsAsTable_sa(str (dir_path) + "\\input\\Coastal_assessment_units\\Coastal_assessment_units.tif", "VALUE", str (dir_output) +"\\open_space_area.tif", str (dir_output) +"\\open_area.dbf", "DATA", "ALL")
   
print "Zonal statistics done"
print (datetime.datetime.now().time()) 

#converting dbase to csv
csv_fn = str (dir_output) +"\\forest_area.csv"
table = dbf.Table(str (dir_output) +"\\forest_area.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) +"\\urban_area.csv"
table = dbf.Table(str (dir_output) +"\\urban_area.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) +"\\arable_area.csv"
table = dbf.Table(str (dir_output) +"\\arable_area.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

csv_fn = str (dir_output) +"\\open_area.csv"
table = dbf.Table(str (dir_output) +"\\open_area.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

print "conversion dbf to csv done "
print (datetime.datetime.now().time())

###Forest
#merge dataframes
table = pd.read_csv (str (dir_output) +"\\forest.csv")
table2 = pd.read_csv (str (dir_output) +"\\forest_area.csv")

result = pd.merge (table, table2, on = 'value')
result = result [['value','sum_x','count_x', 'sum_y']]
result.columns = ['value', 'Cells_forest', 'TotalNrCells', 'ForestArea_m2']
result ['ForestArea_km2'] = 0
result ['PC_forest'] = 0

Table=result.to_csv (str (dir_output) +"\\forest.csv", sep =';', mode='w', index=False)

def landuse (lst): 
	
	value = lst [0]
	Cells_forest = lst [1]
	TotalNrCells = lst [2]
	Area_m2 = lst [3]
	ForestArea_km2 = lst [4]
	PC_forest = lst[5]
	
	ForestArea_km2 = Area_m2/1000000
	PC_forest = (Cells_forest * 100)/TotalNrCells
	return [value, Cells_forest, TotalNrCells, Area_m2, ForestArea_km2, PC_forest]
	
f= open(str (dir_output) +"\\forest.csv")
header= f.readline()

test= map (lambda line: landuse (map (lambda a: float(a),line.split (';'))), f.readlines())
#test= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f.readlines()[0:100])

output = open(str (dir_output) +"\\forest_result.csv", 'w')

output.write (header) 

for line in test:
    s =  ";".join(map(lambda a: str(a),line))
    output.write (s+"\n")

output.close()

print 'done'	

###Urban
#merge dataframes
table = pd.read_csv (str (dir_output) +"\\urban.csv")
table2 = pd.read_csv (str (dir_output) +"\\urban_area.csv")

result = pd.merge (table, table2, on = 'value')
result = result [['value','sum_x','count_x', 'sum_y']]
result.columns = ['value', 'Cells_urban', 'TotalNrCells', 'UrbanArea_m2']
result ['UrbanArea_km2'] = 0
result ['PC_urban'] = 0

Table=result.to_csv (str (dir_output) +"\\urban.csv", sep =';', mode='w', index=False)

def landuse (lst): 
	
	value = lst [0]
	Cells_urban = lst [1]
	TotalNrCells = lst [2]
	Area_m2 = lst [3]
	UrbanArea_km2 = lst [4]
	PC_urban = lst[5]
	
	UrbanArea_km2 = Area_m2/1000000
	PC_urban = (Cells_urban * 100)/TotalNrCells
	return [value, Cells_urban, TotalNrCells, Area_m2, UrbanArea_km2, PC_urban]
	
f= open(str (dir_output) +"\\urban.csv")
header= f.readline()

test= map (lambda line: landuse (map (lambda a: float(a),line.split (';'))), f.readlines())
#test= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f.readlines()[0:100])

output = open(str (dir_output) +"\\urban_result.csv", 'w')

output.write (header) 

for line in test:
    s =  ";".join(map(lambda a: str(a),line))
    output.write (s+"\n")

output.close()

print 'done'

###arable
#merge dataframes
table = pd.read_csv (str (dir_output) +"\\arable_land.csv")
table2 = pd.read_csv (str (dir_output) +"\\arable_area.csv")

result = pd.merge (table, table2, on = 'value')
result = result [['value','sum_x','count_x', 'sum_y']]
result.columns = ['value', 'Cells_arable', 'TotalNrCells', 'arableArea_m2']
result ['arableArea_km2'] = 0
result ['PC_arable'] = 0

Table=result.to_csv (str (dir_output) +"\\arable.csv", sep =';', mode='w', index=False)

def landuse (lst): 
	
	value = lst [0]
	Cells_arable = lst [1]
	TotalNrCells = lst [2]
	Area_m2 = lst [3]
	arableArea_km2 = lst [4]
	PC_arable = lst[5]
	
	arableArea_km2 = Area_m2/1000000
	PC_arable = (Cells_arable * 100)/TotalNrCells
	return [value, Cells_arable, TotalNrCells, Area_m2, arableArea_km2, PC_arable]
	
f= open(str (dir_output) +"\\arable.csv")
header= f.readline()

test= map (lambda line: landuse (map (lambda a: float(a),line.split (';'))), f.readlines())
#test= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f.readlines()[0:100])

output = open(str (dir_output) +"\\arable_result.csv", 'w')

output.write (header) 

for line in test:
    s =  ";".join(map(lambda a: str(a),line))
    output.write (s+"\n")

output.close()

print 'done'

###openspace
#merge dataframes
table = pd.read_csv (str (dir_output) +"\\open_space.csv")
table2 = pd.read_csv (str (dir_output) +"\\open_area.csv")

result = pd.merge (table, table2, on = 'value')
result = result [['value','sum_x','count_x', 'sum_y']]
result.columns = ['value', 'Cells_open', 'TotalNrCells', 'openArea_m2']
result ['openArea_km2'] = 0
result ['PC_open'] = 0

Table=result.to_csv (str (dir_output) +"\\open.csv", sep =';', mode='w', index=False)

def landuse (lst): 
	
	value = lst [0]
	Cells_open = lst [1]
	TotalNrCells = lst [2]
	Area_m2 = lst [3]
	openArea_km2 = lst [4]
	PC_open = lst[5]
	
	openArea_km2 = Area_m2/1000000
	PC_open = (Cells_open * 100)/TotalNrCells
	return [value, Cells_open, TotalNrCells, Area_m2, openArea_km2, PC_open]
	
f= open(str (dir_output) +"\\open.csv")
header= f.readline()

test= map (lambda line: landuse (map (lambda a: float(a),line.split (';'))), f.readlines())
#test= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f.readlines()[0:100])

output = open(str (dir_output) +"\\open_result.csv", 'w')

output.write (header) 

for line in test:
    s =  ";".join(map(lambda a: str(a),line))
    output.write (s+"\n")

output.close()

print 'done'

#Merge dataframes
table = pd.read_csv (str (dir_output) +"\\forest_result.csv", sep =';')
table1 = pd.read_csv (str (dir_output) +"\\urban_result.csv", sep =';')
table2 = pd.read_csv (str (dir_output) +"\\arable_result.csv", sep =';')
table3 = pd.read_csv (str (dir_output) +"\\open_result.csv", sep =';')

print table
print table1


result = pd.merge (table, table1, on = 'value')
result = pd.merge (result, table2, on = 'value')
result = pd.merge (result, table3, on = 'value')
Table=result.to_csv (str (dir_output) +"\\landuse.csv", sep =';', mode='w', index=False)

print Table

