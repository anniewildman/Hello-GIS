# Author: Claudia Wolff
# Date: 2017-10-10
# Purpose:
# Mediterranean coastal database  
# Calculates the exposed areas (hydrologically connected) per elevation increment (1..20m) in km²

#Create an  input and output folder as subfolders of the diretory where this script is stored  
#Save in the input folder the following data 
#1. Elevation data (SRTM90 http://data.cgiar-csi.org/srtm/tiles) .Download.Clip the study extent and convert NoData to 0. Name it as srtm90_med_0.tif and save it.
#2. Create a watermask from the SRTM data (reclassifiy SRTM data -> NoData (Water) = 0; Land = 1). Name it srtm_wtmak_med_final.tif.
#3. Download the Coastal_assessment_units (Coastal_assessment_units.tif) from the figshare folder. 
#4. Create a real area grid (name it real_area.tif) based on this equation https://badc.nerc.ac.uk/help/coordinates/cell-surf-area.html with the same cell size as the elevation data


#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
import os 

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\area"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\area"


arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")
arcpy.env.overwriteOutput = True

#assign variables
h1 = 1
h2 = 2
h3 = 3
h4 = 4
h5 = 5
h6 = 6
h7 = 7
h8 = 8
h9 = 9
h10 = 10
h11 = 11
h12 = 12
h13 = 13
h14 = 14
h15 = 15
h16 = 16
h17 = 17
h18 = 18
h19 = 19
h20 = 20 

#Create a list of the height increments
heightList = [h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19,h20]

#Calculate the floodplain per increment
#reclassify 
#Flexible reclassification range --> remap="-428 " + str(height) + " 1;" + str(height+1) + " 5620 0"

for height in heightList:
arcpy.Reclassify_3d(in_raster= str(dir_input) + '\\srtm90_med_0.tif', reclass_field="VALUE", 
remap="-428 " + str(height) + " 1;" + str(height+1) + " 5620 0", 
out_raster=str(dir_output) + " \\rec" + str(height), missing_values="DATA")

print "reclassify succeeded"
print (datetime.datetime.now().time())

#region group - hydrological connectivity
for height in heightList:
	arcpy.gp.RegionGroup_sa(str(dir_output) + "\\rec" + str(height), str(dir_output) + " \\rg" + str(height), "EIGHT", "WITHIN", "ADD_LINK", "")
	
print "region group succeeded"
print (datetime.datetime.now().time())

#reclassify region group in order to get the area below height x - hydrologically connected 
#elevMAXResult is the maximum value of the region group file

for height in heightList:
	x = int(arcpy.GetCellValue_management(str(dir_output) + "\\rg" + str(height), "-22 44", "").getOutput(0))
	y = x+1
	z = x-1
	elevMAXResult = int(arcpy.GetRasterProperties_management(str(dir_output) + "\\rg" + str(height), "MAXIMUM").getOutput(0))
	arcpy.Reclassify_3d(in_raster=str(dir_output) + "\\rg" + str(height), reclass_field="VALUE", 
	remap=str(x)+ " " + str(x) + " 1;" + str(y) + " " + str(elevMAXResult) + " 0;0 " + str(z) + " 0", out_raster=str(dir_output) + "\\rec_rg" + str(height), missing_values="DATA")
	
print "reclassify of region group succeeded"
print (datetime.datetime.now().time())

#times ocean mask in order to kick the ocean out --> Final indundation areas 
for height in heightList:
	arcpy.gp.Times_sa(str(dir_output) + "\\rec_rg" + str(height), 
	str(dir_input) + "\\srtm_wtmak_med_final.tif", str(dir_output) + "\\times" + str(height))

print "times succeeded"
print (datetime.datetime.now().time())

#times * real_Area_grid in order to get the real area in m²

for height in heightList:
	arcpy.gp.Times_sa(str(dir_output) + "\\times" + str(height), str(dir_input) + "\\real_area.tif", str(dir_output) + "\\r_area" + str(height)) 
	
print "calculate real area - output in m2"
print (datetime.datetime.now().time())

#zonal statistics of the real area 
for height in heightList:
	arcpy.gp.ZonalStatisticsAsTable_sa(str(dir_input) + "\\Coastal_assessment_units.tif", 
	"VALUE", str(dir_output) + "\\r_area" + str(height), str(dir_output) + "\\zonal_area" + str(height) + ".dbf", "DATA", "SUM")

print "zonal statistics done"
print (datetime.datetime.now().time())

#conversion from dbf to csv

for height in heightList:
	csv_fn = str(dir_output) + "\\zonal_area" + str(height) + ".csv"
	table = dbf.Table(str(dir_output) + "\\zonal_area" + str(height) + ".dbf")
	table.open()
	dbf.export (table,csv_fn,header=True)

print "done"
print (datetime.datetime.now().time())

#merge csv's    
#dataframe that have the correct length
table = pd.read_csv (str(dir_output) + "\zonal_area1.csv")
table = table [['value']]
print table

#number of zones
count = 16117

for height in heightList:
	#create dataframe
	vars()['zonal_area' + str(height)] = pd.read_csv (str(dir_output) + "\\zonal_area" + str(height) + ".csv")
	#select columns
	vars()['zonal_area' + str(height) + '_select'] = vars()['zonal_area' + str(height)][['value', 'sum']]
	#rename columns
	vars()['zonal_area' + str(height) + '_select'].columns = ['value', 'area' + str(height)]
	#merge tables/columns
	table = pd.merge(table,vars()['zonal_area' + str(height) + '_select'].loc[:count] , on='value')

Table=table.to_csv (str(dir_output) + "\\zonal_area_all.csv", sep =';', mode='w', index=False)

###converting the cumulative area numbers into area per increment in km²

def area (lst):
   
	value = lst [0]
	area01 = lst [1]
	area02 = lst [2]
	area03 = lst [3]
	area04 = lst [4]    
	area05 = lst [5]
	area06 = lst [6]
	area07 = lst [7]
	area08 = lst [8]
	area09 = lst [9]
	area10 = lst [10]
	area11 = lst [11]
	area12 = lst [12]
	area13 = lst [13]
	area14 = lst [14]
	area15 = lst [15]
	area16 = lst [16]
	area17 = lst [17]
	area18 = lst [18]
	area19 = lst [19]
	area20 = lst [20]
	
	area20 = (area20 - area19)/1000000
	area19 = (area19 - area18)/1000000
	area18 = (area18 - area17)/1000000
	area17 = (area17 - area16)/1000000
	area16 = (area16 - area15)/1000000
	area15 = (area15 - area14)/1000000
	area14 = (area14 - area13)/1000000
	area13 = (area13 - area12)/1000000
	area12 = (area12 - area11)/1000000
	area11 = (area11 - area10)/1000000
	area10 = (area10 - area09)/1000000
	area09 = (area09 - area08)/1000000
	area08 = (area08 - area07)/1000000
	area07 = (area07 - area06)/1000000
	area06 = (area06 - area05)/1000000
	area05 = (area05 - area04)/1000000
	area04 = (area04 - area03)/1000000
	area03 = (area03 - area02)/1000000
	area02 = (area02 - area01)/1000000
	area01 = area01/1000000        
	return [value, area01, area02, area03, area04, area05, area06, area07, area08, area09, area10, area11, area12, area13, area14, area15, area16, area17, area18, area19, area20]  
       

f= open(str(dir_output) + "\\zonal_area_all.csv")
header= f.readline()

test= map (lambda line: area (map (lambda a: float(a),line.split (';'))), f.readlines())
output = open(str(dir_output) + "\\zonal_area_all_converted.csv", 'w')

output.write (header) 

for line in test:
	s =  ";".join(map(lambda a: str(a),line))
	output.write (s+"\n")

output.close()
print 'done'



