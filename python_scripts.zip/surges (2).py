# Author: Claudia Wolff
# Date: 2017-10-12
# Purpose:Mediterranean coastal database
# Processing the extreme water level and surge data

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. Extreme water/surge levels: GTSR and DCESL datasets
# 2. Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3. Create a midpoint shapefile of the segments. Name it segment_midpt.shp


#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\surges"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\surges"

#####GTSR extreme sea levels data
#Spatial join - GTSR extreme water levels data points to cls midpoint (clostest)

target_features= str(dir_input) + "\\segment_midpt.shp"
join_features=str(dir_input) + "\\MEDI_Ids.shp"
out_feature_class=str(dir_output) + "\\IVM_surges.shp"

arcpy.SpatialJoin_analysis(target_features, join_features, out_feature_class, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", match_option="CLOSEST")

#converting dbase to csv
csv_fn = str(dir_output) + "\\IVM_surges.csv"
table = dbf.Table(str(dir_output) + "\\IVM_surges.dbf")
table.open()
dbf.export (table,csv_fn,header=True)
 
print "surges IVM done"
print (datetime.datetime.now().time())

####DCESL extreme sea levels data
target_features= str(dir_input) + "\\segment_midpt.shp"
join_features=str(dir_input) + "\\midpoint_cls_p26.shp"
out_feature_class=str(dir_output) + "\\DIVA_surges_med.shp"

arcpy.SpatialJoin_analysis(target_features, join_features, out_feature_class, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", match_option="CLOSEST")

#converting dbase to csv
csv_fn = str(dir_output) + "\\DIVA_surges_med.csv"
table = dbf.Table(str(dir_output) + "\\DIVA_surges_med.dbf")
table.open()
dbf.export (table,csv_fn,header=True)

print "surges old DIVA surges done"
print (datetime.datetime.now().time())
