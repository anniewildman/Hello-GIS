# Author: Claudia Wolff
# Date: 2016-05-10
# Purpose:Mediterranean coastal database
# Processing the Mean dynamic topography

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. Rio, M.-H., A. Pascual, P.-M. Poulain, M. Menna, B. Barceló, and J. Tintoré : Computation of a new mean dynamic topography for the Mediterranean Sea from model outputs, 
#	altimeter measurements and oceanographic in situ data. Ocean Science, 10, 731-744 , 2014. http://www.ocean-sci.net/10/731/2014/os-10-731-2014.html. doi: 10.5194/os-10-731-2014.
#	website https://www.aviso.altimetry.fr/index.php?id=1281 . Name it SMDT-MED-2014-REF20.nc
# 2. Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3. Create a midpoint shapefile of the segments. Name it


#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
from osgeo import ogr
import csv,sys

arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\MDT"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\MDT"

#Netcdf to raster 
arcpy.MakeNetCDFRasterLayer_md(in_netCDF_file=str(dir_input) + "\\SMDT-MED-2014-REF20.nc", 
	variable="mdt", x_dimension="lon", y_dimension="lat", out_raster_layer=str(dir_output) + "\\mdt_Layer_med.tif", band_dimension="", dimension_values="", value_selection_method="BY_VALUE")
	
# #Raster to points
# arcpy.RasterToPoint_conversion(in_raster=str (dir_output) + "\\mdt_Layer_med.tif", 
	# out_point_features=str (dir_output) + "\\mdt_points.shp", raster_field="Value")
	
# #Join the closest MDT value to the midpoint of the segment
# arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str (dir_output) + "\\mdt_points.shp", 
	# out_feature_class=str (dir_output) + "\\MDT.shp", 
	# join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,segment_midpt.shp,ID_p,-1,-1;
	# MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,segment_midpt.shp,MEAN_ID_p,-1,-1;POINTID "POINTID" true true false 6 Long 0 6 ,First,#,mdt_points,POINTID,-1,-1;
	# GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,mdt_points,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="distance")

# #converting dbase to csv
# csv_fn = str (dir_output) + "\\MDT.csv"
# table = dbf.Table(str (dir_output) + "\\MDT.dbf")
# table.open()
# dbf.export (table,csv_fn,header=True)	