# Author: Claudia Wolff
# Date: 2017-10-17
# Purpose:Mediterranean coastal database
# Processing the tidal data 

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. Tidal data given by Mark Pickering (Ocean and Earth Science, Southampton, UK) as part of his PhD studies 
#    This data is the present day global tidal range. It shows a global field of present day MLW and therefore (by combination with the MHW dataset) a global field of MTR at 1/8 x 1/8 degree resolution.
# 2. Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3. Create a mask shapefile of the study area extent in order to be able to clip the raster datasets. Name it clip.shp
# 4. Create a midpoint shapefile of the segments. Name it segment_midpt.shp

#Convert mat file to raster (the data was availale in a .mat format)

#1 Step: In Matlab
# % Importing data
# load('MTR_MHW_MLW_maxHW_minLW_0mControl_per_r1.mat')

# % Converting NaNs 
# maxHW(isnan(maxHW))=-99999;
# MHW(isnan(MHW))=-99999;
# minLW(isnan(minLW))=-99999;
# MLW(isnan(MLW))=-99999;
# MTR(isnan(MTR))=-99999;

# % Reshaping data
# maxHW_new=zeros(size(maxHW));
# for i=1:length(maxHW)
    # maxHW_new(:,i)=maxHW(:,length(maxHW)-i+1);
    # MHW_new(:,i)=MHW(:,length(MHW)-i+1);
    # minLW_new(:,i)=minLW(:,length(minLW)-i+1);
    # MLW_new(:,i)=MLW(:,length(MLW)-i+1);
    # MTR_new(:,i)=MTR(:,length(MTR)-i+1);
# end

# for i=1:1440;
    # maxHW_new(i,:)=maxHW(1440-i+1,:);
    # MHW_new(i,:)=MHW(1440-i+1,:);
    # minLW_new(i,:)=minLW(1440-i+1,:);
    # MLW_new(i,:)=MLW(1440-i+1,:);
    # MTR_new(i,:)=MTR(1440-i+1,:);
# end

# % Exporting (precision changes depending on data!)
# dlmwrite('MTR.txt',MTR_new,'delimiter','\t','precision',3)


#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\tide"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\tide"
from arcpy.sa import *



#ASCIIToRaster_conversion
arcpy.ASCIIToRaster_conversion(in_ascii_file=str(dir_input) + "\\maxHW.txt", out_raster=str(dir_output) + "\\maxHW", data_type="FLOAT")
arcpy.ASCIIToRaster_conversion(in_ascii_file=str(dir_input) + "\\MHW.txt", out_raster=str(dir_output) + "\\MHW", data_type="FLOAT")
arcpy.ASCIIToRaster_conversion(in_ascii_file=str(dir_input) + "\\minLW.txt", out_raster=str(dir_output) + "\\minLW", data_type="FLOAT")
arcpy.ASCIIToRaster_conversion(in_ascii_file=str(dir_input) + "\\MLW.txt", out_raster=str(dir_output) + "\\MLW", data_type="FLOAT")
arcpy.ASCIIToRaster_conversion(in_ascii_file=str(dir_input) + "\\MTR.txt", out_raster=str(dir_output) + "\\MTR", data_type="FLOAT")

arcpy.DefineProjection_management(in_dataset=str(dir_output) + "\\maxHW", coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
arcpy.DefineProjection_management(in_dataset=str(dir_output) + "\\MHW", coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
arcpy.DefineProjection_management(in_dataset=str(dir_output) + "\\minLW", coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
arcpy.DefineProjection_management(in_dataset=str(dir_output) + "\\MLW", coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
arcpy.DefineProjection_management(in_dataset=str(dir_output) + "\\MTR", coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")

print "ASCIIToRaster_conversion done"
print (datetime.datetime.now().time())

##Clip tidal data to the Mediterranean extent 
arcpy.Clip_management(in_raster=str(dir_output) + "\\maxhw", rectangle="0 26,7341020674342 360 48,3871972204897", out_raster=str(dir_output) + "\\maxhw_med", 
    in_template_dataset=str(dir_input) + "\\clip.shp", nodata_value="#", clipping_geometry="ClippingGeometry", maintain_clipping_extent="MAINTAIN_EXTENT")
arcpy.Clip_management(in_raster=str(dir_output) + "\\MHW", rectangle="0 26,7341020674342 360 48,3871972204897", out_raster=str(dir_output) + "\\MHW_med", 
    in_template_dataset=str(dir_input) + "\\clip.shp", nodata_value="#", clipping_geometry="ClippingGeometry", maintain_clipping_extent="MAINTAIN_EXTENT")
arcpy.Clip_management(in_raster=str(dir_output) + "\\minLW", rectangle="0 26,7341020674342 360 48,3871972204897", out_raster=str(dir_output) + "\\minLW_med", 
    in_template_dataset=str(dir_input) + "\\clip.shp", nodata_value="#", clipping_geometry="ClippingGeometry", maintain_clipping_extent="MAINTAIN_EXTENT")
arcpy.Clip_management(in_raster=str(dir_output) + "\\MLW", rectangle="0 26,7341020674342 360 48,3871972204897", out_raster=str(dir_output) + "\\MLW_med", 
    in_template_dataset=str(dir_input) + "\\clip.shp", nodata_value="#", clipping_geometry="ClippingGeometry", maintain_clipping_extent="MAINTAIN_EXTENT")
arcpy.Clip_management(in_raster=str(dir_output) + "\\MTR", rectangle="0 26,7341020674342 360 48,3871972204897", out_raster=str(dir_output) + "\\MTR_med", 
    in_template_dataset=str(dir_input) + "\\clip.shp", nodata_value="#", clipping_geometry="ClippingGeometry", maintain_clipping_extent="MAINTAIN_EXTENT")

print "Clip done"
print (datetime.datetime.now().time())
    
#Set null
arcpy.gp.SetNull_sa(str(dir_output) + "\\maxhw_med", str(dir_output) + "\\maxhw_med", str(dir_output) + "\\maxhw_null", "VALUE = -100000")
arcpy.gp.SetNull_sa(str(dir_output) + "\\MHW_med", str(dir_output) + "\\MHW_med", str(dir_output) + "\\MHW_null", "VALUE = -100000")
arcpy.gp.SetNull_sa(str(dir_output) + "\\minLW_med", str(dir_output) + "\\minLW_med", str(dir_output) + "\\minLW_null", "VALUE = -100000")
arcpy.gp.SetNull_sa(str(dir_output) + "\\MLW_med", str(dir_output) + "\\MLW_med", str(dir_output) + "\\MLW_null", "VALUE = -100000")
arcpy.gp.SetNull_sa(str(dir_output) + "\\MTR_med", str(dir_output) + "\\MTR_med", str(dir_output) + "\\MTR_null", "VALUE = -100000")

print "set null done"
print (datetime.datetime.now().time())

#raster to points
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\maxhw_null", out_point_features=str(dir_output) + "\\maxhw_points.shp", raster_field="Value")
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\MHW_null", out_point_features=str(dir_output) + "\\MHW_points.shp", raster_field="Value")
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\minLW_null", out_point_features=str(dir_output) + "\\minLW_points.shp", raster_field="Value")
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\MLW_null", out_point_features=str(dir_output) + "\\MLW_points.shp", raster_field="Value")
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\MTR_null", out_point_features=str(dir_output) + "\\MTR_points.shp", raster_field="Value")

#sptial join (midpoint of the segment to the tidal grid/point - closest)
#maxhw
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\maxhw_points.shp", 
	out_feature_class=str(dir_output) + "\\maxhw_sp.shp", join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", 
	field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:/DIVA/MED/database/python/Gis/Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;
	POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/maxhw_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/maxhw_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")

#MHW
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\MHW_points.shp", 
	out_feature_class=str(dir_output) + "\\MHW_sp.shp", join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", 
	field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:/DIVA/MED/database/python/Gis/Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;
	POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MHW_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MHW_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")
	
#minLW
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\minLW_points.shp", 
	out_feature_class=str(dir_output) + "\\minLW_sp.shp", join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", 
	field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:/DIVA/MED/database/python/Gis/Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;
	POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/minLW_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/minLW_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")
	
#MLW
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\MLW_points.shp", 
	out_feature_class=str(dir_output) + "\\MLW_sp.shp", join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", 
	field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:/DIVA/MED/database/python/Gis/Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;
	POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MLW_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MLW_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")
	
#MTR	
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\MTR_points.shp", 
	out_feature_class=str(dir_output) + "\\MTR_sp.shp", join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", 
	field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:/DIVA/MED/database/python/Gis/Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;
	POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MTR_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/tidal/missingsegments/MTR_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")
	
print "spatial join done"
print (datetime.datetime.now().time())
	
#dbf to csv
csv_fn1 = str(dir_output) + "\\maxhw_sp.csv"
csv_fn2 = str(dir_output) + "\\MHW_sp.csv"
csv_fn3 = str(dir_output) + "\\minLW_sp.csv"
csv_fn4 = str(dir_output) + "\\MLW_sp.csv"
csv_fn5 = str(dir_output) + "\\MTR_sp.csv"

table1 = dbf.Table(str(dir_output) + "\\maxhw_sp.dbf")
table2 = dbf.Table(str(dir_output) + "\\MHW_sp.dbf")
table3 = dbf.Table(str(dir_output) + "\\minLW_sp.dbf")
table4 = dbf.Table(str(dir_output) + "\\MLW_sp.dbf")
table5 = dbf.Table(str(dir_output) + "\\MTR_sp.dbf")

table1.open()
table2.open()
table3.open()
table4.open()
table5.open()

dbf.export (table1,csv_fn1,header=True)
dbf.export (table2,csv_fn2,header=True)
dbf.export (table3,csv_fn3,header=True)
dbf.export (table4,csv_fn4,header=True)
dbf.export (table5,csv_fn5,header=True)
	
print "conversion dbf to csv done "
print (datetime.datetime.now().time())


#merge data
#maxHW
maxHW = pd.read_csv (str(dir_output) + "\\maxHW_sp.csv", sep =',')
maxHW.rename (columns = {'id_p' : 'locationid', 'grid_code' : 'maxHW' }, inplace= True)
maxHW ["locationid"] = maxHW.locationid.map("{:005}".format)
maxHW = maxHW [['locationid', 'maxHW']]

#MHW
MHW = pd.read_csv (str(dir_output) + "\\MHW_sp.csv", sep =',')
MHW.rename (columns = {'id_p' : 'locationid', 'grid_code' : 'MHW' }, inplace= True)
MHW ["locationid"] = MHW.locationid.map("{:005}".format)
MHW = MHW [['locationid', 'MHW']]

tide = pd.merge(maxHW,MHW, how= 'left', on=['locationid'])

#minLW
minLW = pd.read_csv (str(dir_output) + "\\minLW_sp.csv", sep =',')
minLW.rename (columns = {'id_p' : 'locationid', 'grid_code' : 'minLW' }, inplace= True)
minLW ["locationid"] = minLW.locationid.map("{:005}".format)
minLW = minLW [['locationid', 'minLW']]

tide = pd.merge(tide,minLW, how= 'left', on=['locationid'])

#MLW
MLW = pd.read_csv (str(dir_output) + "\\MLW_sp.csv", sep =',')
MLW.rename (columns = {'id_p' : 'locationid', 'grid_code' : 'MLW' }, inplace= True)
MLW ["locationid"] = MLW.locationid.map("{:005}".format)
MLW = MLW [['locationid', 'MLW']]

tide = pd.merge(tide,MLW, how= 'left', on=['locationid'])

#MTR
MTR = pd.read_csv (str(dir_output) + "\\MTR_sp.csv", sep =',')
MTR.rename (columns = {'id_p' : 'locationid', 'grid_code' : 'MTR' }, inplace= True)
MTR ["locationid"] = MTR.locationid.map("{:005}".format)
MTR = MTR [['locationid', 'MTR']]

tide = pd.merge(tide,MTR, how= 'left', on=['locationid'])

Table=tide.to_csv (str(dir_output) + "\\tide_data_fin.csv", sep =';', mode='w', index=False)

