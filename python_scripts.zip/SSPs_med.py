#Autor: Claudia Wolff
#Date: 2016-11-15
#Purpose: Mediterranean coatsal database
#Calculate SSP growth rates and total population per time step
#
# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. 	Reimann, L, Merkens, J-L, Vafeidis, A T (2017): Regionalized Shared Socioeconomic Pathways: 
#		narratives and spatial population projections for the Mediterranean coastal zone. In: Regional Environmental Change. DOI: 10.1007/s10113-017-1189-2. 
#		https://figshare.com/articles/Regionalized_Mediterranean_SSP_population_projections/4187295
# 2. 	Download the Coastal_assessment_units (Coastal_assessment_units.tif) from the figshare folder.
# 3. Create a mask shapefile for the Mediterranean in order to clip the rasters. Name it mask_clip.shp

#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\SSP_med"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\SSP_med"

#assign variables - time step
t1 = 2015
t2 = 2020
t3 = 2025
t4 = 2030
t5 = 2035
t6 = 2040
t7 = 2045
t8 = 2050
t9 = 2055
t10 = 2060
t11 = 2065
t12 = 2070
t13 = 2075
t14 = 2080
t15 = 2085
t16 = 2090
t17 = 2095
t18 = 2100

SSP1 = 1
SSP2 = 2
SSP3 = 3
SSP4 = 4
SSP5 = 5


Create a list of the time steps and SSP's
SSPList = [SSP1, SSP2, SSP3, SSP4, SSP5]
timeList = [t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18] 


#clip
for ssp in SSPList:
	for time in timeList:
		arcpy.Clip_management(in_raster=str(dir_input) + "\\pcount_SSP" + str(ssp) + "_" + str(time) + ".tif", 
			rectangle="-9,26739501953125 21,9177856445313 40,3681030273438 49,7575073242188", 
			out_raster=str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + ".tif", 
			in_template_dataset=str (dir_input) + "\\mask_clip.shp", 
			nodata_value="NoData", clipping_geometry="ClippingGeometry", 
			maintain_clipping_extent="NO_MAINTAIN_EXTENT")

#Resample. (to the same cell size as the zones)
for ssp in SSPList:
	for time in timeList:
		arcpy.Resample_management(in_raster=str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + ".tif",
		out_raster=str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_rs.tif", 
		cell_size="0,00083333333", 
		resampling_type="NEAREST")
	
print "done gr_med_rs"

#convert integer to float
for ssp in SSPList:
	for time in timeList:
		arcpy.gp.Float_sa(str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_rs.tif", str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_rsf.tif")

print 'Converting integer to float done'

#divide by 100 in this case in order to account for the resampling

for ssp in SSPList:
	for time in timeList:
		arcpy.gp.Divide_sa(str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_rsf.tif", "100", str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_100.tif")
		
print "done gpw_fin"

#Convert NoData to 0
for ssp in SSPList:
	for time in timeList:
		arcpy.gp.RasterCalculator_sa("""Con(IsNull(" """ + str(dir_output) +  """\\clip_SSP""" + str(ssp) + """_""" + str(time) + """_100.tif"),0," """+ str(dir_output) +  """\\clip_SSP""" + str(ssp) + """_""" + str(time) + """_100.tif")""", str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_0.tif")

print 'NoData to 0 transformed'
		
#Zonal statistics
for ssp in SSPList:
	for time in timeList:
		arcpy.gp.ZonalStatisticsAsTable_sa(str(dir_path) + "\\input\\area\\Coastal_assessment_units.tif", "VALUE", 
		str(dir_output) + "\\clip_SSP" + str(ssp) + "_" + str(time) + "_0.tif", str(dir_output) + "\\SSP" + str(ssp) + "_" + str(time) + "_medNew.dbf", "DATA", "ALL")

print "SSP zonal statistics done"	
print (datetime.datetime.now().time())


#Conversion from dbf to csv
for ssp in SSPList:
	for time in timeList:
		csv_fn = str(dir_output) + "\\SSP" + str(ssp) + "_" + str(time) + "_medNew.csv"
		table = dbf.Table(str(dir_output) + "\\SSP" + str(ssp) + "_" + str(time) + "_medNew.dbf")
		table.open()
		dbf.export (table,csv_fn,header=True)

print "SSP - conversion dbf to csv done"
print (datetime.datetime.now().time())
	
#merge csv's	
#dataframe that have the correct length
table = pd.read_csv (str(dir_output) + "\\SSP" + str(ssp) + "_" + str(time) + "_medNew.csv")
table = table [['value']]

#number of zones
count = 16117

for ssp in SSPList:
	for time in timeList:
		#create dataframe
		vars()['SSP' + str(ssp)+ "_" + str(time) + "_med"] = pd.read_csv (str(dir_output) + "\\SSP" + str(ssp) + "_" + str(time) + "_medNew.csv")
		#select columns
		vars()['SSP' + str(ssp)+ "_" + str(time) + "_med_select"] = vars()['SSP' + str(ssp)+ "_" + str(time) + "_med"][['value', 'sum']]
		#rename columns
		vars()['SSP' + str(ssp)+ "_" + str(time) + "_med_select"].columns = ['value', 'SSP' + str(ssp)+ '_' + str(time)]
		#merge tables/columns
		table = pd.merge(table,vars()['SSP' + str(ssp)+ "_" + str(time) + "_med_select"].loc[:count] , on='value')

table= table.fillna(0)
table.to_csv (str(dir_output) + "\\SSP_all.csv", sep =';', encoding='utf-8', index= False)

#add column and calculate growthrate
table2 = table

timeList = [t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16]

for time in timeList:
	table2 ['GR_SSP1_'+ str(time)+'_'+str(time+5)] = ((table2['SSP1_' +str(time +5)] / table2['SSP1_'+str(time)])**(0.2))-1
	
table2 ['GR_SSP1_2095_2100'] = ((table2.SSP1_2100 / table2.SSP1_2095)**(0.2))-1

for time in timeList:
	table2 ['GR_SSP2_'+ str(time)+'_'+str(time+5)] = ((table2['SSP2_' +str(time +5)] / table2['SSP2_'+str(time)])**(0.2))-1
	
table2 ['GR_SSP2_2095_2100'] = ((table2.SSP2_2100 / table2.SSP2_2095)**(0.2))-1
	
for time in timeList:
	table2 ['GR_SSP3_'+ str(time)+'_'+str(time+5)] = ((table2['SSP3_' +str(time +5)] / table2['SSP3_'+str(time)])**(0.2))-1
	
table2 ['GR_SSP3_2095_2100'] = ((table2.SSP3_2100 / table2.SSP3_2095)**(0.2))-1
	
for time in timeList:
	table2 ['GR_SSP4_'+ str(time)+'_'+str(time+5)] = ((table2['SSP4_' +str(time +5)] / table2['SSP4_'+str(time)])**(0.2))-1
	
table2 ['GR_SSP4_2095_2100'] = ((table2.SSP4_2100 / table2.SSP4_2095)**(0.2))-1
	
for time in timeList:
	table2 ['GR_SSP5_'+ str(time)+'_'+str(time+5)] = ((table2['SSP5_' +str(time +5)] / table2['SSP5_'+str(time)])**(0.2))-1
	
table2 ['GR_SSP5_2095_2100'] = ((table2.SSP5_2100 / table2.SSP5_2095)**(0.2))-1

table2 = table2.fillna(0)


table2.to_csv (str(dir_output) + "\\\GrowthratesNewZonesMed.csv", sep =';',mode='w', index=False)

print "SSPGrowthrates done"
print (datetime.datetime.now().time())




