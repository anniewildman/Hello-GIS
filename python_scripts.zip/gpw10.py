# Author: Claudia Wolff
# Date: 2017-10-11
# Purpose:
# DIVA database input 
# Calculates the number of people lying in the flooded area (hydrologically connected) per increment (1..20m)


# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data: 
# 1. Global Population of the World 2010 (Center for International Earth Science, Information Network , Columbia University.) Name it gpw2010_med. 
#    Clip it to the study extent (The population data should have the same extent as the area files). 
# 2. Download the Coastal_assessment_units (Coastal_assessment_units.tif) from the figshare folder.
# 3. Area 1...20 grids and zonal_area_all_converted.csv. You can create both with the area.py script. 
# 4. Create a watermask from the SRTM data (reclassifiy SRTM data -> NoData (Water) = 1; Land = 0). Name it srtm_wtmak_med_final.tif.  

#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\pop"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\pop"

#resample the population data to the same cell size as the elevation data
try: 
 arcpy.Resample_management(in_raster=str(dir_input) + '\\gpw2010_med.tif',
 out_raster=str(dir_output) + '\\gpw2010_med_rs.tif', 
 cell_size="0,00083333333", 
 resampling_type="NEAREST")
 
except:
 print" Output already exist"
	
print "done gpw2010_med_rs"

##divide by 100 in this case in order to account for the resampling
try: 
 arcpy.gp.Divide_sa(str(dir_output) + '\\gpw2010_med_rs.tif', "100", str(dir_output) + "\\gpw2010_fin.tif")
except:
 print " gpw2010_fin already exist"

print "done gpw2010_fin"

#assign variables
h1 = 1
h2 = 2
h3 = 3
h4 = 4
h5 = 5
h6 = 6
h7 = 7
h8 = 8
h9 = 9
h10 = 10
h11 = 11
h12 = 12
h13 = 13
h14 = 14
h15 = 15
h16 = 16
h17 = 17
h18 = 18
h19 = 19
h20 = 20 

#Create a list of the height increments
heightList = [h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19,h20] 

# #population times the area increments

# for height in heightList:
	# arcpy.gp.Times_sa(str(dir_output) + "\\gpw2010_fin.tif", str(dir_path) + "\\output\\area\\times" + str(height) , str(dir_output) + "\\pop_gpw2010" + str(height))

# print "done"
# print (datetime.datetime.now().time())

# #zonal statistics
# for height in heightList:
	# arcpy.gp.ZonalStatisticsAsTable_sa(str(dir_path) + "\\input\\area\\Coastal_assessment_units.tif", 
	# "VALUE", str(dir_output) + "\\pop_gpw2010" + str(height), 
	# str(dir_output) + "\\gpw2010_zonal" + str(height) + ".dbf", "DATA", "ALL")

# print "Zonal statistics done"	
# print (datetime.datetime.now().time())
	
##population that falls into the ocean 

# #ocean mask times population dataset
# arcpy.gp.Times_sa(str(dir_output) + "\\gpw2010_fin.tif", 
	# str(dir_input) + "\\water_mask", 
	# str(dir_output) + "\\oc_gpw2010")

# print "Population that falls into the ocean- times done"	
# print (datetime.datetime.now().time())
	
# #zonal statistics
# arcpy.gp.ZonalStatisticsAsTable_sa(str(dir_path) + "\\input\\area\\Coastal_assessment_units.tif",
	# "VALUE", str(dir_output) + "\\oc_gpw2010", 
	# str(dir_output) + "\\zonal_oc_gpw2010.dbf", "DATA", "ALL")
	
# print "Population that falls into the ocean- zonal statistics done"	
# print (datetime.datetime.now().time())

# # conversion from dbf to csv
# for height in heightList:
	# csv_fn = str(dir_output) + "\\gpw2010_zonal" + str(height) + ".csv"
	# table = dbf.Table(str(dir_output) + "\\gpw2010_zonal" + str(height) + ".dbf")
	# table.open()
	# dbf.export (table,csv_fn,header=True)


# print "conversion dbf to csv done"
# print (datetime.datetime.now().time())

csv_fn = str(dir_output) + "\\zonal_ocean_gpw2010.csv"
table = dbf.Table(str(dir_output) + "\\zonal_oc_gpw2010.dbf")
table.open()
dbf.export (table,csv_fn,header=True)
	
print "conversion dbf to csv done for the ocean"
print (datetime.datetime.now().time())

#merge csv's    
#dataframe that have the correct length
table = pd.read_csv (str(dir_output) + "\\gpw2010_zonal1.csv")
table = table [['value']]
print table

#number of zones
count = 13900

for height in heightList:
	#create dataframe
	vars()['pop_zonal_gpw2010' + str(height)] = pd.read_csv (str(dir_output) + "\\gpw2010_zonal" + str(height) + ".csv")
	#select columns
	vars()['pop_zonal_gpw2010' + str(height) + '_select'] = vars()['pop_zonal_gpw2010' + str(height)][['value', 'sum']]
	#rename columns
	vars()['pop_zonal_gpw2010' + str(height) + '_select'].columns = ['value', 'pop' + str(height)]
	#merge tables/columns
	table = pd.merge(table,vars()['pop_zonal_gpw2010' + str(height) + '_select'].loc[:count] , on='value')

Table=table.to_csv (str(dir_output) + "\\pop_all_gpw2010.csv", sep =';', mode='w', index=False)

###converting the cumulative area numbers into area per increment

def area (lst):
    
    value = lst [0]
    pop01 = lst [1]
    pop02 = lst [2]
    pop03 = lst [3]
    pop04 = lst [4]    
    pop05 = lst [5]
    pop06 = lst [6]
    pop07 = lst [7]
    pop08 = lst [8]
    pop09 = lst [9]
    pop10 = lst [10]
    pop11 = lst [11]
    pop12 = lst [12]
    pop13 = lst [13]
    pop14 = lst [14]
    pop15 = lst [15]
    pop16 = lst [16]
    pop17 = lst [17]
    pop18 = lst [18]
    pop19 = lst [19]
    pop20 = lst [20]

    pop20 = (pop20 - pop19)
    pop19 = (pop19 - pop18)
    pop18 = (pop18 - pop17)
    pop17 = (pop17 - pop16)
    pop16 = (pop16 - pop15)
    pop15 = (pop15 - pop14)
    pop14 = (pop14 - pop13)
    pop13 = (pop13 - pop12)
    pop12 = (pop12 - pop11)
    pop11 = (pop11 - pop10)
    pop10 = (pop10 - pop09)
    pop09 = (pop09 - pop08)
    pop08 = (pop08 - pop07)
    pop07 = (pop07 - pop06)
    pop06 = (pop06 - pop05)
    pop05 = (pop05 - pop04)
    pop04 = (pop04 - pop03)
    pop03 = (pop03 - pop02)
    pop02 = (pop02 - pop01)
    pop01 = pop01        
    return [value, pop01, pop02, pop03, pop04, pop05, pop06, pop07, pop08, pop09, pop10, pop11, pop12, pop13, pop14, pop15, pop16, pop17, pop18, pop19, pop20]  
        

f= open(str(dir_output) + "\\pop_all_gpw2010.csv")
header= f.readline()

test= map (lambda line: area (map (lambda a: float(a),line.split (';'))), f.readlines())
#test= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f.readlines()[0:100])

output = open(str(dir_output) + "\\pop_all_gpw2010_converted.csv", 'w')

output.write (header) 

for line in test:
    s =  ";".join(map(lambda a: str(a),line))
    output.write (s+"\n")

output.close()

print "merge tables and calculate the population per increment done"
print (datetime.datetime.now().time())

#Correct the mismatch of elvelation and population data
#merge area and population+popocean table


area = pd.read_csv (str(dir_path) + "\\output\\area\\zonal_area_all_converted.csv", sep =';')
pop_gpw20102000 = pd.read_csv (str(dir_output) + "\\pop_all_gpw2010_converted.csv",sep =';')

ocean_gpw20102000 = pd.read_csv (str(dir_output) + "\\zonal_ocean_gpw2010.csv",sep =',')

ocean_gpw20102000 = ocean_gpw20102000 [['value', 'sum']]

#merge dataframes
result_gpw20102000 = area.merge (pop_gpw20102000, on='value')
result_gpw20102000_oc = result_gpw20102000.merge (ocean_gpw20102000, on='value')

#save csv's
result_gpw20102000_oc.to_csv (str(dir_output) + "\\area_gpw2010.csv", sep =',', encoding='utf-8',index=False)

def popocean_correction (lst):
    
    locationid = lst [0]
    area01 = lst [1]
    area02 = lst [2]
    area03 = lst [3]
    area04 = lst [4]
    area05 = lst [5]
    area06 = lst [6]
    area07 = lst [7]
    area08 = lst [8]
    area09 = lst [9]
    area10 = lst [10]
    area11 = lst [11]
    area12 = lst [12]
    area13 = lst [13]
    area14 = lst [14]
    area15 = lst [15]
    area16 = lst [16]
    area17 = lst [17]
    area18 = lst [18]
    area19 = lst [19]
    area20 = lst [20]
    
    pop01 = lst [21]
    pop02 = lst [22]
    pop03 = lst [23]
    pop04 = lst [24]
    pop05 = lst [25]
    pop06 = lst [26]
    pop07 = lst [27]
    pop08 = lst [28]
    pop09 = lst [29]
    pop10 = lst [30]
    pop11 = lst [31]
    pop12 = lst [32]
    pop13 = lst [33]
    pop14 = lst [34]
    pop15 = lst [35]
    pop16 = lst [36]
    pop17 = lst [37]
    pop18 = lst [38]
    pop19 = lst [39]
    pop20 = lst [40]
        
    pop0cean = lst [41]
    
    if area01> 0: 
        pop01 = pop01 + pop0cean
        pop0cean = 0
        #print pop01
    elif area02> 0:
        pop02 = pop02 + pop0cean
        pop0cean = 0
    elif area03> 0:
        pop03 = pop03 + pop0cean
        pop0cean = 0
    elif area04> 0:
        pop04 = pop04 + pop0cean
        pop0cean = 0
    elif area05> 0:
        pop05 = pop05 + pop0cean
        pop0cean = 0
    elif area06> 0:
        pop06 = pop06 + pop0cean
        pop0cean = 0
    elif area07> 0:
        pop07 = pop07 + pop0cean
        pop0cean = 0
    elif area08> 0:
        pop08 = pop08 + pop0cean
        pop0cean = 0
    elif area09> 0:
        pop09 = pop09 + pop0cean
        pop0cean = 0
    elif area10> 0:
        pop10 = pop10 + pop0cean
        pop0cean = 0
    elif area11> 0:
        pop11 = pop11 + pop0cean
        pop0cean = 0
    elif area12> 0:
        pop12 = pop12 + pop0cean
        pop0cean = 0
    elif area13> 0:
        pop13 = pop13 + pop0cean
        pop0cean = 0
    elif area14> 0:
        pop14 = pop14 + pop0cean
        pop0cean = 0
    elif area15> 0:
        pop15 = pop15 + pop0cean
        pop0cean = 0
    elif area16> 0:
        pop16 = pop16 + pop0cean
        pop0cean = 0
    elif area17> 0:
        pop17 = pop17 + pop0cean
        pop0cean = 0
    elif area18> 0:
        pop18 = pop18 + pop0cean
        pop0cean = 0
    elif area19> 0:
        pop19 = pop19 + pop0cean
        pop0cean = 0
    elif area20> 0:
        pop20 = pop20 + pop0cean
        pop0cean = 0
    else: 
        pop0cean = pop0cean
    return [locationid, area01, area02, area03, area04, area05, area06, area07, area08, area09, area10, area11, area12, area13, area14, area15, area16, area17, area18, area19, area20, pop01, pop02, pop03, pop04, pop05, pop06, pop07, pop08, pop09, pop10, pop11, pop12, pop13, pop14, pop15, pop16, pop17, pop18, pop19, pop20, pop0cean]  
        

f1= pd.read_csv (str(dir_output) + "\\area_gpw2010.csv")
f1.to_csv (str(dir_output) + "\\area_gpw2010.csv", sep =';', encoding='utf-8',index=False)
f1= open(str(dir_output) + "\\area_gpw2010.csv")

header1= f1.readline()

test1= map (lambda line: popocean_correction (map (lambda a: float(a),line.split (';'))), f1.readlines())

output1 = open(str(dir_output) + "\\area_gpw2010_ocean_corrected.csv", 'w')

output1.write (header1) 

for line in test1:
	s =  ";".join(map(lambda a: str(a),line))
	output1.write (s+"\n")

output1.close()

print 'done'
