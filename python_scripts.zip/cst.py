#Autor: Claudia Wolff
#Date: 2017-11-02
#Purpose: calculate the Mediterranean coastal slope 

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1. GEBCO_2014 Grid — a global 30 arc-second interval grid
#	 http://www.gebco.net/data_and_products/gridded_bathymetry_data/
#	 Ascii export to raster (WGS_84) in ArcGIS. Clip to study area extent --> Name it: GEBCO_med.tif
# 2. Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3. Create a midpoint shapefile of the segments. Name it segment_midpt.shp

#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\cst"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\cst"


#Project raster. x,y,z need to be in the same unit
arcpy.ProjectRaster_management(in_raster=  str(dir_input) + "\\GEBCO_med.tif", out_raster=str(dir_output) + "\\GEBCO_med_pj.tif", 
	out_coor_system="PROJCS['WGS_1984_World_Mercator',GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Mercator'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',0.0],PARAMETER['Standard_Parallel_1',0.0],UNIT['Meter',1.0]]", resampling_type="NEAREST", cell_size="1049,91254371364 1049,91254371364", 
	geographic_transform="", Registration_Point="", in_coor_system="GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")

#calculate the slope
arcpy.gp.Slope_sa(str(dir_output) + "\\GEBCO_med_pj.tif", str(dir_output) + "\\gebco_slope.tif", "DEGREE", "1")

#extract values that intersect with the coastline in order to calculate the slope directly on the coast
arcpy.gp.ExtractByMask_sa(str(dir_output) + "\\gebco_slope.tif", str (dir_path) + "\\input\\Coastal_Segments\\Mediterranean_segments.shp", str(dir_output) + "\\extract.tif")

#Raster extract to points
arcpy.RasterToPoint_conversion(in_raster=str(dir_output) + "\\extract.tif", out_point_features=str(dir_output) + "\\extract_points.shp", raster_field="Value")

#spatial join with midpoints of the segment - clostest
arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", join_features=str(dir_output) + "\\extract_points.shp", out_feature_class=str(dir_output) + "\\spatialjoin.shp", 
	join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="""ID_p "ID_p" true true false 5 Short 0 5 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,ID_p,-1,-1;
	MEAN_ID_p "MEAN_ID_p" true true false 19 Double 0 0 ,First,#,E:\DIVA\MED\database\python\Gis\Med_coast_final2017_midpt_test.shp,MEAN_ID_p,-1,-1;POINTID "POINTID" true true false 6 Long 0 6 ,First,#,E:/DIVA/MED/database/python/Gis/Slope/extract_points.shp,POINTID,-1,-1;
	GRID_CODE "GRID_CODE" true true false 17 Double 8 16 ,First,#,E:/DIVA/MED/database/python/Gis/Slope/extract_points.shp,GRID_CODE,-1,-1""", match_option="CLOSEST", search_radius="", distance_field_name="")

print "GIS work done"
print (datetime.datetime.now().time())

#conversion vom dbf to csv
csv_fn = str(dir_output) + "\\zonal_cst.csv"
table = dbf.Table(str(dir_output) + "\\spatialjoin.dbf")
table.open()
dbf.export (table,csv_fn,header=True)
	
print "conversion dbf to csv done"
print (datetime.datetime.now().time())

f1= pd.read_csv (str(dir_output) + "\\zonal_cst.csv", sep =',')
slope = f1 [['id_p', 'grid_code']]
slope = slope.rename (columns = {'grid_code':'cst'})
slope.to_csv (str(dir_output) + "\\cst.csv", sep =';', encoding='utf-8',index=False)
