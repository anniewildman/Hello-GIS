#Autor: Claudia Wolff
#Date: 2017-10-12
#Purpose: Mediterranean coatsal database 
#Regionalized SLR scenarios, which account for regional gravitational and rotational effects 
#due to changes in ice mass distribution and steric changes. Mean sea-level rise relative to 1985-2005 [m] for RCP 2.6, 4.5 and 8.5 for a high ice-sheet melting scenario. 

# Create an  input and output folder as subfolders of the diretory where this script is stored  
# Save in the input folder the following data:
# 1.SLR scenarios (Regionalized SLR scenarios, which account for regional gravitational and rotational effects due to changes in ice 
#	mass distribution and steric changes. Mean sea-level rise relative to 1985-2005 [m] for RCP 2.6, 4.5 and 8.5 for a high ice-sheet melting scenario. )
#	Sources: Hinkel et al. 2014. Preparing the netCDF's in ArcGIS desktop. NetCDF_time_slice_to_Raster tool (download:http://support.esri.com/technical-article/000011318) .Make netCDF raster Layer.
#	Name the folder and data: rcp" + str (rcp) + "_hig/Band_" + str(band) + ".tif"
#	Execute the NetCDF_time_slice_to_Raster tool
# 2.Coastal segments (Mediterranean_segments.shp) from the fighshare repository
# 3.Create a midpoint shapefile of the segments. Name it segment_midpt.shp

#import modules
import arcpy
import datetime
import psycopg2
import csv
import pandas as pd
import simpledbf
import dbf
from sqlalchemy import create_engine
from operator import add
import os
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

arcpy.env.overwriteOutput = True

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_input = os.path.dirname(os.path.realpath(__file__)) + "\\input\\SLR\\hig"
dir_output = os.path.dirname(os.path.realpath(__file__)) + "\\output\\SLR\\hig"

#assign variables - time step

Band_1 = 1
Band_2 = 2
Band_3 = 3
Band_4 = 4
Band_5 = 5
Band_6 = 6
Band_7 = 7
Band_8 = 8
Band_9 = 9
Band_10 =10
Band_11 =11
Band_12 =12
Band_13 =13
Band_14 =14
Band_15 =15
Band_16 =16
Band_17 =17
Band_18 =18
Band_19 =19
Band_20 =20
Band_21 =21
Band_22 =22

rcp26_hig = 26 
rcp45_hig = 45
rcp85_hig = 85

bandList = [Band_1, Band_2, Band_3, Band_4, Band_5, Band_6, Band_7, Band_8, Band_9, Band_10, Band_11, Band_12, Band_13, Band_14, Band_15, Band_16, Band_17, Band_18, Band_19, Band_20, Band_21, Band_22]
rcpList = [rcp26_hig, rcp45_hig, rcp85_hig]


for rcp in rcpList:
	for band in bandList:
		#raster to points
		arcpy.RasterToPoint_conversion(in_raster=str(dir_input) + "\\rcp" + str (rcp) + "_hig\\Band_" + str(band) + ".tif", 
			out_point_features=str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Band_" + str(band) + ".shp", raster_field="Value")


#spatial join clostest
fieldmappings = arcpy.FieldMappings()

for rcp in rcpList:
	for band in bandList:
		arcpy.SpatialJoin_analysis(target_features=str(dir_input) + "\\segment_midpt.shp", 
			join_features=str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Band_" + str(band) + ".shp", 
			out_feature_class=str(dir_output) + "\\rcp" + str (rcp) + "_hig\\join_Band_" + str(band) + ".shp", 
			join_operation="JOIN_ONE_TO_MANY", 
			join_type="KEEP_ALL", 
			field_mapping= fieldmappings, 
			match_option="CLOSEST", search_radius="", distance_field_name="dis")

print 'spatial join done'
		
#Dissolve
for rcp in rcpList:
	for band in bandList: 
		arcpy.Dissolve_management(in_features=str(dir_output) + "\\rcp" + str (rcp) + "_hig\\join_Band_" + str(band) + ".shp", 
			out_feature_class=str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Bandfi_" + str(band) + ".dbf", dissolve_field="ID_p", 
			statistics_fields="grid_code MEAN", multi_part="MULTI_PART", unsplit_lines="DISSOLVE_LINES")

			
			
#Conversion from dbf to csv
for rcp in rcpList:
	for band in bandList:
		csv_fn = str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Bandfi_" + str(band) + ".csv"
		table = dbf.Table(str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Bandfi_" + str(band) + ".dbf")
		table.open()
		dbf.export (table,csv_fn,header=True)

print "RCP SC. - conversion dbf to csv done"
print (datetime.datetime.now().time())

print 'converon to csv done'

#merge csv's	
#dataframe that have the correct length
table = pd.read_csv (str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Bandfi_1.csv")
table = table [['id_p']]

#number of zones
count = 11990

year=['locationid','RCP26_1995', 'RCP26_2000', 'RCP26_2005', 'RCP26_2010', 'RCP26_2015', 'RCP26_2020', 'RCP26_2025', 'RCP26_2030', 'RCP26_2035', 'RCP26_2040', 'RCP26_2045', 'RCP26_2050', 'RCP26_2055', 'RCP26_2060', 'RCP26_2065',
        'RCP26_2070', 'RCP26_2075', 'RCP26_2080', 'RCP26_2085', 'RCP26_2090', 'RCP26_2095', 'RCP26_2100','RCP45_1995', 'RCP45_2000', 'RCP45_2005', 'RCP45_2010', 'RCP45_2015', 'RCP45_2020', 'RCP45_2025', 'RCP45_2030', 'RCP45_2035',
        'RCP45_2040', 'RCP45_2045', 'RCP45_2050', 'RCP45_2055', 'RCP45_2060', 'RCP45_2065','RCP45_2070', 'RCP45_2075', 'RCP45_2080', 'RCP45_2085', 'RCP45_2090', 'RCP45_2095', 'RCP45_2100',
        'RCP85_1995', 'RCP85_2000', 'RCP85_2005', 'RCP85_2010', 'RCP85_2015', 'RCP85_2020', 'RCP85_2025', 'RCP85_2030', 'RCP85_2035', 'RCP85_2040', 'RCP85_2045', 'RCP85_2050', 'RCP85_2055', 'RCP85_2060', 'RCP85_2065',
        'RCP85_2070', 'RCP85_2075', 'RCP85_2080', 'RCP85_2085', 'RCP85_2090', 'RCP85_2095', 'RCP85_2100']

for rcp in rcpList:
	for band in bandList:
		#create dataframe
		vars()['RCP' + str(rcp)+ "_" + str(band)] = pd.read_csv (str(dir_output) + "\\rcp" + str (rcp) + "_hig\\Bandfi_" + str(band) + ".csv")
		#select columns
		vars()['RCP' + str(rcp)+ "_" + str(band) + "_select"] = vars()['RCP' + str(rcp)+ "_" + str(band)][['id_p', 'mean_grid_']]
		#rename columns
		#vars()['RCP' + str(rcp)+ "_" + str(band)+ "_select"].columns = ['mean_grid_', 'RCP' + str(rcp)+ '_' + str(band)]
		#merge tables/columns
		table = pd.merge(table,vars()['RCP' + str(rcp)+ "_" + str(band)+ "_select"].loc[:count] , on='id_p')
		print table
		
#rename columns
table.columns = year
print table
table.to_csv (str(dir_output) + "\\ISIMIP_all_high.csv", sep =',', encoding='utf-8')

